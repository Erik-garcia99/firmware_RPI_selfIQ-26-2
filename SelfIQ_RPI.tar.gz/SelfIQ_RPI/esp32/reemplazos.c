/* REFERENCIA: copie estas funciones sobre las homónimas, NO añada este archivo
 * al CMake junto con las originales (duplicaría símbolos).
 * Cambie MAX_DATA a 160 y RPI_IP_SETUP a "192.168.50.1".
 * main.c ya tiene los includes y variables globales usados aquí.
 * En tcp_lib.c añada stdbool.h, stdlib.h y freertos/task.h si faltan.
 * No imprime credenciales por UART.
 */

/* tcp_lib.c: recepción exacta, válida también con fragmentación TCP. */
static bool selfiq_recv_exact(uint8_t *dst, size_t count) {
  size_t done = 0;
  while (done < count) {
    int n = recv(tcp_client.sock, dst + done, count - done, 0);
    if (n > 0) done += (size_t)n;
    else if (n < 0 && errno == EINTR) continue;
    else return false; /* timeout incluido: setup_tcp reintentará */
  }
  return true;
}

void recv_task(void *params) {
  (void)params;
  for (;;) {
    uint8_t prefix[3], body[MAX_DATA + 1];
    if (!selfiq_recv_exact(prefix, sizeof(prefix))) break;
    uint16_t header = ((uint16_t)prefix[0] << 8) | prefix[1];
    uint8_t len = prefix[2];
    bool nack = header == ACK && len == 0xFF;
    if ((header != ACK && header != HEADER) ||
        (!nack && (len < 1 || len > MAX_DATA + 1))) break;
    size_t count = nack ? 2 : len;
    if (!selfiq_recv_exact(body, count)) break;
    if (nack && (body[0] != 0xFF || body[1] != 0)) break;
    TYPE_FORMAT_REQUEST_T *frame = pvPortMalloc(sizeof(*frame));
    if (!frame) break;
    memset(frame, 0, sizeof(*frame));
    frame->header = header;
    frame->len = len;
    frame->type_frame = (body[0] >> 4) & 0x0F;
    frame->action = body[0] & 0x0F;
    if (!nack && len > 1) memcpy(frame->data, body + 1, len - 1);
    if (xQueueSend(tcp_rx_queue, &frame, pdMS_TO_TICKS(100)) != pdTRUE)
      vPortFree(frame);
  }
  tcp_client.connected = 0;
  xEventGroupSetBits(g_tcp_event_group, TCP_DISCONNECTED);
  /* El dueño (setup_tcp) borrará la tarea y cerrará el socket. Así no queda
   * un handle obsoleto que main.c intente borrar otra vez. */
  vTaskSuspend(NULL);
}

esp_err_t send_message(void) {
  uint8_t bytes[5];
  uint16_t header = send_info.op_type == OPReqCredWifi ? HEADER : ACK;
  bytes[0] = header >> 8;
  bytes[1] = header & 0xFF;
  if (send_info.op_type == OPReqCredWifi) {
    bytes[2] = 2; bytes[3] = (eNoType << 4) | eReqWifi; bytes[4] = 0;
  } else if (send_info.op_type == OP_ACK) {
    bytes[2] = 2; bytes[3] = (eRespACK << 4) | action_none; bytes[4] = 1;
  } else if (send_info.op_type == OP_NACK) {
    bytes[2] = 0xFF; bytes[3] = 0xFF; bytes[4] = 0;
  } else return ESP_ERR_INVALID_ARG;
  size_t done = 0;
  while (done < sizeof(bytes)) {
    int n = send(tcp_client.sock, bytes + done, sizeof(bytes) - done, 0);
    if (n > 0) done += (size_t)n;
    else if (n < 0 && errno == EINTR) continue;
    else return ESP_FAIL;
  }
  return ESP_OK;
}

/* main.c: reemplazo que no pierde el bloque anterior si malloc falla. */
esp_err_t update_setup_cred(char *ssid, char *pass, char *user, char *type) {
  bool enterprise = type && strcmp(type, "SETUP_ENTERPRISE_WIFI") == 0;
  if (!ssid || !pass || !type || !ssid[0] || strlen(ssid) > 32 ||
      strlen(pass) > 64 || (enterprise && (!user || !user[0] || strlen(user) > 31)) ||
      (!enterprise && strcmp(type, "SETUP_WIFI") != 0)) return ESP_ERR_INVALID_ARG;
  char *s = malloc(strlen(ssid) + 1);
  char *p = malloc(strlen(pass) + 1);
  char *u = enterprise ? malloc(strlen(user) + 1) : NULL;
  if (!s || !p || (enterprise && !u)) {
    free(s); free(p); free(u); return ESP_ERR_NO_MEM;
  }
  strcpy(s, ssid); strcpy(p, pass);
  if (enterprise) strcpy(u, user);
  free(esp_wifi.ssid); free(esp_wifi.pswd); free(esp_wifi.user_name);
  esp_wifi.ssid = s; esp_wifi.pswd = p; esp_wifi.user_name = u;
  esp_wifi.type_connected = enterprise ? 1 : 0;
  return ESP_OK;
}

void tcp_process_task(void *params) {
  (void)params;
  for (;;) {
    TYPE_FORMAT_REQUEST_T *frame = NULL;
    if (xQueueReceive(tcp_rx_queue, &frame, portMAX_DELAY) != pdTRUE) continue;
    if (!frame) continue;
    bool ok = frame->header == ACK && frame->len != 0xFF &&
              frame->len >= 1 && frame->len <= MAX_DATA + 1 &&
              frame->action == eRespWifi &&
              (frame->type_frame == eWifiDefault || frame->type_frame == eWifiEnterprise);
    size_t offset = 0, data_len = ok ? frame->len - 1 : 0;
    char ssid[33] = {0}, pass[65] = {0}, user[32] = {0};
    bool have_ssid = false, have_pass = false, have_user = false;
    while (ok && offset < data_len) {
      if (data_len - offset < 2) { ok = false; break; }
      uint8_t id = frame->data[offset++], len = frame->data[offset++];
      if (len > data_len - offset || memchr(frame->data + offset, 0, len)) { ok = false; break; }
      char *dst = NULL;
      if (id == eDataSSID && !have_ssid && len >= 1 && len <= 32) {
        dst = ssid; have_ssid = true;
      } else if (id == eDataPSWD && !have_pass && len >= 1 && len <= 64) {
        dst = pass; have_pass = true;
      } else if (id == eDataUSR && !have_user && frame->type_frame == eWifiEnterprise && len >= 1 && len <= 31) {
        dst = user; have_user = true;
      } else { ok = false; break; }
      memcpy(dst, frame->data + offset, len);
      offset += len;
    }
    bool enterprise = frame->type_frame == eWifiEnterprise;
    ok = ok && offset == data_len && have_ssid && have_pass &&
         (enterprise ? have_user : !have_user);
    if (ok) {
      esp_err_t err = update_setup_cred(ssid, pass, enterprise ? user : NULL,
                           enterprise ? "SETUP_ENTERPRISE_WIFI" : "SETUP_WIFI");
      if (err == ESP_OK) {
        send_info.op_type = OP_ACK;
        (void)send_message();
        /* Solo señala éxito después de validar y actualizar toda la trama. */
        vPortFree(frame);
        xEventGroupSetBits(s_wifi_event_group, WIFI_CREDS_READY);
        vTaskSuspend(NULL); /* setup_tcp/main borran esta tarea */
      }
    }
    /* NACK (credenciales aún no disponibles) no dispara ping-pong de NACK. */
    vPortFree(frame);
  }
}

/* main.c: reintento limitado por conexión, sin crear tareas duplicadas. */
void setup_tcp(void) {
  for (;;) {
    xEventGroupClearBits(s_wifi_event_group, WIFI_CREDS_READY);
    xEventGroupClearBits(g_tcp_event_group, TCP_DISCONNECTED);
    if (tcp_cliente_init() != ESP_OK) {
      vTaskDelay(pdMS_TO_TICKS(2000));
      continue;
    }
    bool tasks_ok = xTaskCreate(recv_task, "recv_task", 4096, NULL, 8, &xRecv_task) == pdPASS;
    if (tasks_ok)
      tasks_ok = xTaskCreate(tcp_process_task, "tcp_process_task", 4096, NULL, 8, &xTcp_process_task) == pdPASS;
    send_info.op_type = OPReqCredWifi;
    bool sent = tasks_ok && send_message() == ESP_OK;
    bool ready = false;
    for (int seconds = 0; sent && seconds < 20; ++seconds) {
      EventBits_t bits = xEventGroupWaitBits(s_wifi_event_group, WIFI_CREDS_READY,
                               pdFALSE, pdFALSE, pdMS_TO_TICKS(1000));
      if (bits & WIFI_CREDS_READY) { ready = true; break; }
      if (xEventGroupGetBits(g_tcp_event_group) & TCP_DISCONNECTED) break;
    }
    if (xRecv_task) { vTaskDelete(xRecv_task); xRecv_task = NULL; }
    if (xTcp_process_task) { vTaskDelete(xTcp_process_task); xTcp_process_task = NULL; }
    if (tcp_client.sock >= 0) { close(tcp_client.sock); tcp_client.sock = -1; }
    tcp_client.connected = 0;
    TYPE_FORMAT_REQUEST_T *pending = NULL;
    while (xQueueReceive(tcp_rx_queue, &pending, 0) == pdTRUE) vPortFree(pending);
    if (ready) return;
    vTaskDelay(pdMS_TO_TICKS(2000));
  }
}
