# Cambios necesarios en tu ESP32

El servidor sigue tus constantes reales (global.h/tcp_lib.c); ACTION y TYPE_FRAME
comparten un byte. No es una estructura de cinco campos de un byte cada uno.

En tcp_lib.h:
```c
#define RPI_IP_SETUP "192.168.50.1"
#define RPI_PORT_SETUP 5000
```
En global.h:
```c
#define MAX_DATA 160
#define SSID_LEN_MAX 32
#define PSWD_LEN_MAX 64
#define USER_LEN_MAX 31
```
En main.c, inicializa el descriptor así, porque 0 es un descriptor válido:
```c
TYPE_TCP_CLIENT_T tcp_client = {.sock = -1};
```

En `reemplazos.c` hay funciones para copiar sobre las originales:
- tcp_lib.c: selfiq_recv_exact, recv_task y send_message.
- main.c: update_setup_cred, tcp_process_task y setup_tcp.
No agregues reemplazos.c como otro archivo del proyecto: es una referencia de
integración, no una unidad compilable autónoma. Conserva tus includes, colas,
grupos de eventos y handles. Los includes adicionales de TCP son stdbool.h,
stdlib.h y freertos/task.h. Tu tcp_lib.h puede declarar send_message(void).

Corrige estos problemas presentes en los adjuntos:
1. LEN excluye HEADER y el propio LEN. DATA ocupa LEN-1, no LEN-3.
2. El tipo está en el nibble alto, `(byte >> 4) & 0x0f`; la acción en el bajo,
   `byte & 0x0f`. En la rama ACK no estabas asignando action y leías el tipo
   desde el nibble incorrecto.
3. TCP puede fragmentar o agrupar tramas: recv no es una trama. Lee primero
   tres bytes, luego exactamente LEN; NACK es excepción de longitud 0xFF.
4. Reinicia offset para cada trama, valida campos completos, únicos y
   obligatorios antes de llamar update_setup_cred. No señales WIFI_CREDS_READY
   tras un error o un NACK. Antes incluso se podía llamar strlen(NULL).
5. No imprimas los bytes de respuesta: contienen contraseñas. Tu hex_buf de
   128 bytes además podía desbordarse al imprimir tramas largas.
6. setup_tcp debe reintentar si recibió NACK o se cerró el socket y destruir
   las tareas/objetos anteriores antes de crear otros. La versión adjunta usa
   una espera de 20 s por intento. En tcp_cliente_init agrega SO_SNDTIMEO de
   5 s junto a SO_RCVTIMEO; el envío corregido contempla escrituras parciales.

Los reemplazos no modifican todo tu app_main ni fueron compilados en ESP-IDF.
Después de integrarlos revisa también:
- Si tus credenciales NVS fallan, tu app_main actual solo reporta el fallo.
  Debes volver al flujo de SelfIQ-Admi: update_setup_cred con las credenciales
  del AP, wifi_reconnect, setup_tcp y conexión final. No guardes el AP en NVS.
- Si la conexión final falla, no hagas return definitivo: reintenta el flujo
  de aprovisionamiento con una pausa. Los bloques existentes guardan NVS solo
  después de conexión final; conserva eso.
- Al cambiar de AP a STA la Raspberry puede desaparecer unos segundos. La ESP
  necesita reconectar al AP si pierde Wi-Fi, además de reintentar TCP.
- En wifi_reconnect(), si vence WIFI_DISCONNECT_TIMEOUT_MS, restaura
  manual_disconnect=false antes de devolver; hoy puede quedar true.
- Enterprise requiere configuración EAP compatible y CA en esp_eap_client.
  El TLV acordado transmite solo SSID/usuario/contraseña, no CA ni dominio.
  Provisiona esos parámetros en firmware para la red objetivo y verifica la
  autenticación del servidor; el programa original no lo hace.
- Tu wifi_init_sta acepta WPA2 Personal; este paquete no ofrece redes abiertas,
  WPA3-only, PSK hexadecimal de 64 caracteres ni EAP-TLS con certificados cliente.
